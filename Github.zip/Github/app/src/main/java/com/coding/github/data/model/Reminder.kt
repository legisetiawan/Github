package com.coding.github.data.model

data class Reminder(
    var isReminder:Boolean = false
)
